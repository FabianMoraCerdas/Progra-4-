const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const path = require('path');

const app = express();

// Middlewares
app.use(express.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static('public'));

// Conexión a MySQL
const conexion = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'PrograCUC',
  database: 'banco'
});

conexion.connect(error => {
  if (error) {
    console.error('❌ Error al conectar con la BD:', error);
    return;
  }
  console.log('✅ Conectado a la base de datos MySQL');
});

// -------------------- Ruta: Registrar Cliente y Tutor (si es menor) --------------------
app.post('/api/clientes', (req, res) => {
  const { nombre, apellido, cedula, tipo_identificacion, fecha_nacimiento, tutor } = req.body;

  // Validar campos obligatorios
  if (!nombre || !apellido || !cedula || !tipo_identificacion || !fecha_nacimiento) {
    return res.status(400).send("⚠️ Faltan datos obligatorios.");
  }

  // Calcular edad
  const nacimiento = new Date(fecha_nacimiento);
  const hoy = new Date();
  let edad = hoy.getFullYear() - nacimiento.getFullYear();
  const mes = hoy.getMonth() - nacimiento.getMonth();
  if (mes < 0 || (mes === 0 && hoy.getDate() < nacimiento.getDate())) {
    edad--;
  }

  // Insertar cliente
  const sqlCliente = `INSERT INTO clientes (nombre, apellido, cedula, tipo_identificacion, fecha_nacimiento, edad)
                      VALUES (?, ?, ?, ?, ?, ?)`;

  conexion.query(sqlCliente, [nombre, apellido, cedula, tipo_identificacion, fecha_nacimiento, edad], (err, result) => {
    if (err) {
      console.error("❌ Error al registrar cliente:", err.sqlMessage || err.message);
      return res.status(500).send("Error en la base de datos: " + (err.sqlMessage || err.message));
    }

    const clienteId = result.insertId;

    // Si es menor de edad y se proporciona tutor
    if (edad < 18 && tutor) {
      const sqlTutor = `INSERT INTO tutores (cliente_id, nombre, apellido, cedula)
                        VALUES (?, ?, ?, ?)`;

      conexion.query(sqlTutor, [clienteId, tutor.nombre, tutor.apellido, tutor.cedula], (err2) => {
        if (err2) {
          console.error("⚠️ Cliente registrado pero error al guardar tutor:", err2);
          return res.status(500).send("Cliente registrado, pero error al guardar tutor.");
        }
        res.send("✅ Cliente y tutor registrados correctamente.");
      });
    } else {
      res.send("✅ Cliente registrado correctamente.");
    }
  });
});

// -------------------- Ruta: Apertura de Cuentas --------------------
app.post('/api/cuentas', (req, res) => {
  const { clienteId, tipoCuenta, saldoInicial } = req.body;

  if (!clienteId || !tipoCuenta || saldoInicial === undefined) {
    return res.status(400).send('⚠️ Faltan datos obligatorios.');
  }

  if (!['colones', 'dolares'].includes(tipoCuenta)) {
    return res.status(400).send('⚠️ Tipo de cuenta inválido.');
  }

  const saldo = parseFloat(saldoInicial);
  if (isNaN(saldo) || saldo < 0) {
    return res.status(400).send('⚠️ Saldo inicial inválido.');
  }

  const sqlCliente = 'SELECT * FROM clientes WHERE id = ?';
  conexion.query(sqlCliente, [clienteId], (err, clientes) => {
    if (err) return res.status(500).send('❌ Error en la base de datos.');
    if (clientes.length === 0) return res.status(404).send('❌ Cliente no encontrado.');

    const tipoCuentaCode = tipoCuenta === 'colones' ? 'CR01' : 'CR02';
    const numeroCuenta = tipoCuentaCode + clienteId.toString().padStart(10, '0') + Date.now().toString().slice(-5);

    const sqlInsert = `INSERT INTO cuentas (cliente_id, tipo_cuenta, numero_cuenta, saldo, fecha_apertura)
                       VALUES (?, ?, ?, ?, CURDATE())`;

    conexion.query(sqlInsert, [clienteId, tipoCuenta, numeroCuenta, saldo], (err2) => {
      if (err2) return res.status(500).send('❌ Error al registrar la cuenta.');

      res.send(`✅ Cuenta creada correctamente. Número: ${numeroCuenta}`);
    });
  });
});

// -------------------- Ruta: Movimiento (Depósito, Retiro, Consulta) --------------------

app.post('/api/movimiento', (req, res) => {
  const { numeroCuenta, tipo, monto, descripcion } = req.body;

  if (!numeroCuenta || !tipo) {
    return res.status(400).send('Datos incompletos');
  }

  // Para depósito o retiro monto debe ser válido y > 0
  if ((tipo === 'deposito' || tipo === 'retiro') && (!monto || monto <= 0)) {
    return res.status(400).send('Monto inválido');
  }

  if (tipo === 'consulta') {
    const sqlConsulta = `SELECT saldo FROM cuentas WHERE numero_cuenta = ?`;
    conexion.query(sqlConsulta, [numeroCuenta], (err, resultados) => {
      if (err) {
        console.error('❌ Error al consultar saldo:', err);
        return res.status(500).send('Error al consultar saldo');
      }
      if (resultados.length === 0) {
        return res.status(404).send('Cuenta no encontrada');
      }
      const saldoActual = resultados[0].saldo;
      return res.send(`💰 Saldo actual: ₡${saldoActual}`);
    });
    return;
  }

  if (tipo === 'retiro') {
    // Contar retiros realizados hoy
    const sqlConteo = `
      SELECT COUNT(*) AS cantidad FROM movimientos
      WHERE numero_cuenta = ? AND tipo = 'retiro' AND DATE(fecha) = CURDATE()
    `;

    conexion.query(sqlConteo, [numeroCuenta], (err, resultados) => {
      if (err) {
        console.error('❌ Error al contar retiros:', err);
        return res.status(500).send('Error al contar retiros');
      }

      const cantidad = resultados[0].cantidad;
      let cargo = 0;

      if (cantidad < 2) {
        cargo = monto * 0.02; // 2%
      } else if (cantidad === 2) {
        cargo = monto * 0.03; // 3%
      } else if (cantidad >= 3 && cantidad < 5) {
        cargo = monto * 0.04; // 4%
      } else {
        return res.status(400).send('❌ Límite de 5 retiros diarios alcanzado');
      }

      const montoTotal = monto + cargo;

      // Verificar saldo suficiente con cargo
      const sqlSaldo = `SELECT saldo FROM cuentas WHERE numero_cuenta = ?`;
      conexion.query(sqlSaldo, [numeroCuenta], (err2, resultadoSaldo) => {
        if (err2) {
          console.error('❌ Error al verificar saldo:', err2);
          return res.status(500).send('Error al verificar saldo');
        }
        if (resultadoSaldo.length === 0) {
          return res.status(404).send('Cuenta no encontrada');
        }

        const saldoActual = resultadoSaldo[0].saldo;
        if (saldoActual < montoTotal) {
          return res.status(400).send('❌ Fondos insuficientes para retiro y cargo');
        }

        // Preparar descripción
        const descFinal = descripcion && descripcion.trim() !== '' ? descripcion : 'Retiro realizado';

        // Insertar movimiento con cargo incluido
        const sqlInsert = `INSERT INTO movimientos (numero_cuenta, tipo, monto, descripcion, cargo, fecha)
                           VALUES (?, ?, ?, ?, ?, NOW())`;
        conexion.query(sqlInsert, [numeroCuenta, tipo, monto, descFinal, cargo], (err3) => {
          if (err3) {
            console.error('❌ Error al registrar retiro:', err3);
            return res.status(500).send('Error al registrar retiro');
          }

          // Actualizar saldo restando monto + cargo
          const sqlUpdate = `UPDATE cuentas SET saldo = saldo - ? WHERE numero_cuenta = ?`;
          conexion.query(sqlUpdate, [montoTotal, numeroCuenta], (err4) => {
            if (err4) {
              console.error('❌ Error al actualizar saldo:', err4);
              return res.status(500).send('Error al actualizar saldo');
            }
            return res.send(`✅ Retiro realizado. Cargo aplicado: ₡${cargo.toFixed(2)}`);
          });
        });
      });
    });
    return;
  }

  // Si es depósito
  const descFinal = descripcion && descripcion.trim() !== ''
    ? descripcion
    : 'Depósito realizado';

  const sqlInsert = `INSERT INTO movimientos (numero_cuenta, tipo, monto, descripcion, fecha)
                     VALUES (?, ?, ?, ?, NOW())`;

  conexion.query(sqlInsert, [numeroCuenta, tipo, monto, descFinal], (err, resultado) => {
    if (err) {
      console.error('❌ Error al registrar depósito:', err);
      return res.status(500).send('Error al registrar depósito');
    }

    const sqlUpdate = `UPDATE cuentas SET saldo = saldo + ? WHERE numero_cuenta = ?`;

    conexion.query(sqlUpdate, [monto, numeroCuenta], (err2) => {
      if (err2) {
        console.error('❌ Error al actualizar saldo:', err2);
        return res.status(500).send('Error al actualizar saldo');
      }

      return res.send('✅ Depósito registrado correctamente');
    });
  });
});





// -------------------- Ruta: Historial de Movimientos --------------------

app.get('/api/movimientos/:numeroCuenta', (req, res) => {
  const { numeroCuenta } = req.params;

  if (!numeroCuenta) {
    return res.status(400).json({ error: 'Número de cuenta requerido' });
  }

  const sql = `
    SELECT fecha, tipo, monto, descripcion, COALESCE(cargo, 0) as cargo
    FROM movimientos
    WHERE numero_cuenta = ?
    ORDER BY fecha DESC
  `;

  conexion.query(sql, [numeroCuenta], (err, resultados) => {
    if (err) {
      console.error('Error al obtener historial:', err);
      return res.status(500).json({ error: 'Error en la base de datos' });
    }

    if (resultados.length === 0) {
      return res.status(404).json({ error: 'No hay movimientos para esta cuenta' });
    }

    return res.json(resultados);
  });
});




// -------------------- Puerto del servidor --------------------
const PUERTO = 3000;
app.listen(PUERTO, () => {
  console.log(`🚀 Servidor corriendo en: http://localhost:${PUERTO}`);
});
