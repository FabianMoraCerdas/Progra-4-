CREATE DATABASE IF NOT EXISTS banco;
USE banco;

CREATE TABLE  clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(50),
  apellido VARCHAR(50),
  cedula VARCHAR(20),
  tipo_identificacion VARCHAR(20),
  fecha_nacimiento DATE,
  edad INT
);

CREATE TABLE  tutores (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT,
  nombre VARCHAR(50),
  apellido VARCHAR(50),
  cedula VARCHAR(20),
  FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE CASCADE
);clientes

CREATE TABLE IF NOT EXISTS cuentas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT,
  tipo_cuenta ENUM('colones', 'dolares'),
  numero_cuenta VARCHAR(34) UNIQUE,
  saldo DECIMAL(15, 2) DEFAULT 0,
  fecha_apertura DATE,
  FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE CASCADE
);
CREATE TABLE movimientos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  numero_cuenta VARCHAR(50),
  tipo VARCHAR(20),
  monto DECIMAL(12, 2),
  descripcion TEXT,
  fecha DATETIME
);
ALTER TABLE movimientos ADD COLUMN cargo DECIMAL(10,2) DEFAULT 0;

