function validarFormulario() {
  alert("Gracias por tu mensaje. Nos pondremos en contacto pronto.");
  return false; // Para que no se recargue la página
}