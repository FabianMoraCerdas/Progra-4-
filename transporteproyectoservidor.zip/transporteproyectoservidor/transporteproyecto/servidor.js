const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 8888;

// Configuración de middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('public'));

// Configuración de MIME types
const mimeTypes = {
  'html': 'text/html',
  'css': 'text/css',
  'js': 'application/javascript',
  'json': 'application/json',
  'png': 'image/png',
  'jpg': 'image/jpg',
  'gif': 'image/gif',
  'ico': 'image/x-icon'
};

// Configuración de conexión MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'transporte_user', // Usuario específico
  password: 'PrograCUC', // Contraseña segura
  database: 'transporte_cuc',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});
// Conectar a MySQL
db.connect((err) => {
  if (err) {
    console.error('Error al conectar a MySQL:', err.stack);
    return;
  }
  console.log('Conectado a MySQL como id', db.threadId);
  inicializarBaseDeDatos();
});

// Inicializar la base de datos
function inicializarBaseDeDatos() {
  // Crear tabla de contactos
  db.query(`CREATE TABLE IF NOT EXISTS contactos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    mensaje TEXT NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  )`, (err) => {
    if (err) throw err;
    console.log('Tabla contactos creada/verificada');
  });

  // Crear tabla de reservas
  db.query(`CREATE TABLE IF NOT EXISTS reservas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    telefono VARCHAR(20) NOT NULL,
    correo VARCHAR(100) NOT NULL,
    servicio VARCHAR(50) NOT NULL,
    fecha DATE NOT NULL,
    hora TIME NOT NULL,
    origen VARCHAR(100) NOT NULL,
    destino VARCHAR(100) NOT NULL,
    personas INT NOT NULL,
    comentarios TEXT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  )`, (err) => {
    if (err) throw err;
    console.log('Tabla reservas creada/verificada');
  });
}

// Rutas para manejar formularios
app.post('/api/contacto', (req, res) => {
  const { nombre, email, mensaje } = req.body;
  
  db.query(
    'INSERT INTO contactos (nombre, email, mensaje) VALUES (?, ?, ?)',
    [nombre, email, mensaje],
    (err, results) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json({ id: results.insertId, message: 'Mensaje enviado con éxito' });
    }
  );
});

app.post('/api/reservas', (req, res) => {
  const { nombre, telefono, correo, servicio, fecha, hora, origen, destino, personas, comentarios } = req.body;
  
  // Validar fecha
  const fechaViaje = new Date(fecha);
  const hoy = new Date();
  hoy.setHours(0, 0, 0, 0);
  
  if (fechaViaje < hoy) {
    return res.status(400).json({ error: 'La fecha del viaje no puede ser anterior al día de hoy.' });
  }

  db.query(
    `INSERT INTO reservas (nombre, telefono, correo, servicio, fecha, hora, origen, destino, personas, comentarios) 
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [nombre, telefono, correo, servicio, fecha, hora, origen, destino, personas, comentarios],
    (err, results) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json({ id: results.insertId, message: 'Reserva enviada con éxito' });
    }
  );
});

// Ruta para servir archivos estáticos
app.get('*', (req, res) => {
  let filePath = path.join(__dirname, 'public', req.path === '/' ? 'index.html' : req.path);
  const extname = path.extname(filePath).substring(1);
  const contentType = mimeTypes[extname] || 'application/octet-stream';

  fs.readFile(filePath, (error, content) => {
    if (error) {
      if (error.code === 'ENOENT') {
        res.status(404).send('<!doctype html><html><head></head><body>Recurso inexistente</body></html>');
      } else {
        res.status(500).send('Error interno del servidor');
      }
    } else {
      res.setHeader('Content-Type', contentType);
      res.send(content);
    }
  });
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`Servidor web iniciado en http://localhost:${PORT}`);
});